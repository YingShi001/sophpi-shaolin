#include "videoDec.h"

VideoDec_FFMPEG::VideoDec_FFMPEG()
{
    ifmt_ctx = NULL;
    video_dec_ctx = NULL;
    video_dec_par = NULL;
    decoder = NULL;

    width = 0;
    height = 0;
    pix_fmt = 0;

    video_stream_idx = -1;
    refcount = 1;

    av_init_packet(&pkt);
    pkt.data = NULL;
    pkt.size = 0;

    frame = av_frame_alloc();
}
VideoDec_FFMPEG::~VideoDec_FFMPEG()
{
    closeDec();
    printf("#VideoDec_FFMPEG exit \n");
}

AVCodecParameters *VideoDec_FFMPEG::getCodecPar()
{
    return video_dec_par;
}

int VideoDec_FFMPEG::openDec(const char *filename, int codec_name_flag,
                             const char *coder_name, int output_format_mode,
                             int extra_frame_buffer_num, int sophon_idx, int pcie_no_copyback)
{
    int ret = 0;
    AVDictionary *dict = NULL;
    av_dict_set(&dict, "rtsp_flags", "prefer_tcp", 0);
    ret = avformat_open_input(&ifmt_ctx, filename, NULL, &dict);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "Cannot open input file\n");
        return ret;
    }

    ret = avformat_find_stream_info(ifmt_ctx, NULL);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "Cannot find stream information\n");
        return ret;
    }

#ifdef BM_PCIE_MODE
    ret = openCodecContext(&video_stream_idx, &video_dec_ctx, ifmt_ctx, AVMEDIA_TYPE_VIDEO,
                           codec_name_flag, coder_name, output_format_mode, extra_frame_buffer_num,
                           sophon_idx, pcie_no_copyback);
#else
    ret = openCodecContext(&video_stream_idx, &video_dec_ctx, ifmt_ctx, AVMEDIA_TYPE_VIDEO,
                           codec_name_flag, coder_name, output_format_mode, extra_frame_buffer_num);
#endif
    if (ret >= 0)
    {
        width = video_dec_ctx->width;
        height = video_dec_ctx->height;
        pix_fmt = video_dec_ctx->pix_fmt;
    }
    av_log(video_dec_ctx, AV_LOG_INFO,
           "openDec video_stream_idx = %d, pix_fmt = %d\n",
           video_stream_idx, pix_fmt);
    av_dict_free(&dict);
    return ret;
}

void VideoDec_FFMPEG::closeDec()
{
    if (video_dec_ctx)
    {
        avcodec_free_context(&video_dec_ctx);
        video_dec_ctx = NULL;
    }
    if (ifmt_ctx)
    {
        avformat_close_input(&ifmt_ctx);
        ifmt_ctx = NULL;
    }
    if (frame)
    {
        av_frame_free(&frame);
        frame = NULL;
    }
}

AVCodec *VideoDec_FFMPEG::findBmDecoder(AVCodecID dec_id, const char *name, int codec_name_flag, enum AVMediaType type)
{
    /* find video decoder for the stream */
    AVCodec *codec = NULL;
    if (codec_name_flag && type == AVMEDIA_TYPE_VIDEO)
    {
        const AVCodecDescriptor *desc;
        const char *codec_string = "decoder";

        codec = avcodec_find_decoder_by_name(name);

        if (!codec && (desc = avcodec_descriptor_get_by_name(name)))
        {
            codec = avcodec_find_decoder(desc->id);
        }

        if (!codec)
        {
            av_log(NULL, AV_LOG_FATAL, "Unknown %s '%s'\n", codec_string, name);
            exit(1);
        }
        if (codec->type != type)
        {
            av_log(NULL, AV_LOG_FATAL, "Invalid %s type '%s'\n", codec_string, name);
            exit(1);
        }
    }
    else
    {
        std::cout << "find_decider by ID" << std::endl;
        codec = avcodec_find_decoder(dec_id);
    }

    if (!codec)
    {
        fprintf(stderr, "Failed to find %s codec\n", av_get_media_type_string(type));
        exit(1);
    }
    return codec;
}

int VideoDec_FFMPEG::openCodecContext(int *stream_idx, AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx,
                                      enum AVMediaType type, int codec_name_flag, const char *coder_name,
                                      int output_format_mode, int extra_frame_buffer_num, int sophon_idx, int pcie_no_copyback)
{
    int ret, stream_index;
    AVStream *st;
    AVCodec *dec = NULL;
    AVDictionary *opts = NULL;

    ret = av_find_best_stream(fmt_ctx, type, -1, -1, NULL, 0);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_ERROR, "Could not find %s stream \n", av_get_media_type_string(type));
        return ret;
    }

    stream_index = ret;
    st = fmt_ctx->streams[stream_index];

    /* find decoder for the stream */
    if (codec_name_flag && coder_name)
        decoder = findBmDecoder((AVCodecID)0, coder_name, codec_name_flag, AVMEDIA_TYPE_VIDEO);
    else
        decoder = findBmDecoder(st->codecpar->codec_id);
    if (!decoder)
    {
        av_log(NULL, AV_LOG_FATAL, "Failed to find %s codec\n",
               av_get_media_type_string(type));
        return AVERROR(EINVAL);
    }

    /* Allocate a codec context for the decoder */
    *dec_ctx = avcodec_alloc_context3(decoder);
    if (!*dec_ctx)
    {
        av_log(NULL, AV_LOG_FATAL, "Failed to allocate the %s codec context\n",
               av_get_media_type_string(type));
        return AVERROR(ENOMEM);
    }

    /* Copy codec parameters from input stream to output codec context */
    ret = avcodec_parameters_to_context(*dec_ctx, st->codecpar);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_FATAL, "Failed to copy %s codec parameters to decoder context\n",
               av_get_media_type_string(type));
        return ret;
    }

    video_dec_par = st->codecpar;
    /* Init the decoders, with or without reference counting */
    av_dict_set(&opts, "refcounted_frames", refcount ? "1" : "0", 0);
#ifdef BM_PCIE_MODE
    av_dict_set_int(&opts, "zero_copy", pcie_no_copyback, 0);
    av_dict_set_int(&opts, "sophon_idx", sophon_idx, 0);
#endif
    if (output_format_mode == 101)
        av_dict_set_int(&opts, "output_format", output_format_mode, 18);

    // if(extra_frame_buffer_num > 5)
    // av_dict_set_int(&opts, "extra_frame_buffer_num", extra_frame_buffer_num, 0); // if we use dma_buffer mode
    // av_dict_set_int(&opts, "extra_frame_buffer_num", 1, 0);  // if we use dma_buffer mode

    ret = avcodec_open2(*dec_ctx, dec, &opts);
    if (ret < 0)
    {
        av_log(NULL, AV_LOG_FATAL, "Failed to open %s codec\n",
               av_get_media_type_string(type));
        return ret;
    }
    *stream_idx = stream_index;

    av_dict_free(&opts);

    return 0;
}